#!/bin/bash
# ================================================================
# ArgoCD Complete Setup Script
# - Installs ArgoCD
# - Creates new user: sameer  (password: Sameer@1234)
# - Registers fluid-demo application
# - Connects to GitHub repo
# ================================================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

# ── CONFIG ───────────────────────────────────────────────────────
NEW_USER="sameer"
NEW_PASSWORD="Sameer@1234"          # change this after first login
ARGOCD_NAMESPACE="argocd"
GITHUB_REPO="https://github.com/Sameerkatre/fluid-ai-devops.git"
# ────────────────────────────────────────────────────────────────

banner() {
  echo -e "${GREEN}"
  echo "╔══════════════════════════════════════════════════════╗"
  echo "║         ArgoCD Setup — fluid-ai-devops               ║"
  echo "╚══════════════════════════════════════════════════════╝"
  echo -e "${NC}"
}

step() { echo -e "\n${BLUE}▶ $1${NC}"; }
ok()   { echo -e "${GREEN}  ✓ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }

banner

# ════════════════════════════════════════════════════════════════
step "STEP 1 — Install ArgoCD into cluster"
# ════════════════════════════════════════════════════════════════

kubectl create namespace $ARGOCD_NAMESPACE --dry-run=client -o yaml | kubectl apply -f -

kubectl apply -n $ARGOCD_NAMESPACE \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

echo "Waiting for ArgoCD pods to start (takes ~2 minutes)..."
kubectl wait --for=condition=ready pod \
  -l app.kubernetes.io/name=argocd-server \
  -n $ARGOCD_NAMESPACE \
  --timeout=180s

ok "ArgoCD installed"

# ════════════════════════════════════════════════════════════════
step "STEP 2 — Expose ArgoCD UI as NodePort"
# ════════════════════════════════════════════════════════════════

kubectl patch svc argocd-server \
  -n $ARGOCD_NAMESPACE \
  -p '{"spec": {"type": "NodePort", "ports": [{"port": 443, "targetPort": 8080, "nodePort": 30443, "name": "https"}]}}'

MINIKUBE_IP=$(minikube ip 2>/dev/null || echo "localhost")
ARGOCD_URL="https://${MINIKUBE_IP}:30443"
ok "ArgoCD UI available at: $ARGOCD_URL"

# ════════════════════════════════════════════════════════════════
step "STEP 3 — Get admin password (existing)"
# ════════════════════════════════════════════════════════════════

ADMIN_PASSWORD=$(kubectl -n $ARGOCD_NAMESPACE get secret argocd-initial-admin-secret \
  -o jsonpath="{.data.password}" | base64 -d 2>/dev/null || echo "already-changed")

echo "  Admin username : admin"
echo "  Admin password : $ADMIN_PASSWORD"

# ════════════════════════════════════════════════════════════════
step "STEP 4 — Install ArgoCD CLI"
# ════════════════════════════════════════════════════════════════

if ! command -v argocd &>/dev/null; then
  echo "Installing ArgoCD CLI..."
  OS=$(uname -s | tr '[:upper:]' '[:lower:]')
  ARCH=$(uname -m)
  [ "$ARCH" = "x86_64" ] && ARCH="amd64"
  [ "$ARCH" = "aarch64" ] && ARCH="arm64"

  curl -sSL -o /usr/local/bin/argocd \
    "https://github.com/argoproj/argo-cd/releases/latest/download/argocd-${OS}-${ARCH}"
  chmod +x /usr/local/bin/argocd
  ok "ArgoCD CLI installed"
else
  ok "ArgoCD CLI already installed"
fi

# ════════════════════════════════════════════════════════════════
step "STEP 5 — Login to ArgoCD as admin"
# ════════════════════════════════════════════════════════════════

argocd login ${MINIKUBE_IP}:30443 \
  --username admin \
  --password "$ADMIN_PASSWORD" \
  --insecure \
  --grpc-web

ok "Logged in as admin"

# ════════════════════════════════════════════════════════════════
step "STEP 6 — Create new user: $NEW_USER"
# ════════════════════════════════════════════════════════════════

# Patch argocd-cm to add the new user account
kubectl patch configmap argocd-cm \
  -n $ARGOCD_NAMESPACE \
  --type merge \
  -p "{\"data\": {\"accounts.${NEW_USER}\": \"apiKey, login\", \"admin.enabled\": \"true\"}}"

ok "User '$NEW_USER' added to argocd-cm"

# Wait a moment for ArgoCD to pick up the configmap change
sleep 5

# Set password for the new user using ArgoCD CLI
argocd account update-password \
  --account "$NEW_USER" \
  --new-password "$NEW_PASSWORD" \
  --current-password "$ADMIN_PASSWORD"

ok "Password set for user '$NEW_USER'"

# ════════════════════════════════════════════════════════════════
step "STEP 7 — Apply RBAC: give $NEW_USER full access"
# ════════════════════════════════════════════════════════════════

kubectl apply -f argocd-rbac-cm.yaml
ok "RBAC policy applied — $NEW_USER has admin-level access"

# ════════════════════════════════════════════════════════════════
step "STEP 8 — Login as new user to verify"
# ════════════════════════════════════════════════════════════════

argocd login ${MINIKUBE_IP}:30443 \
  --username "$NEW_USER" \
  --password "$NEW_PASSWORD" \
  --insecure \
  --grpc-web

ok "Login as '$NEW_USER' successful"
argocd account get-user-info

# ════════════════════════════════════════════════════════════════
step "STEP 9 — Register GitHub repo in ArgoCD"
# ════════════════════════════════════════════════════════════════

argocd repo add "$GITHUB_REPO" \
  --name fluid-ai-devops \
  --insecure-skip-server-verification 2>/dev/null || \
  warn "Repo already registered or is public — skipping"

ok "GitHub repo registered"

# ════════════════════════════════════════════════════════════════
step "STEP 10 — Create ArgoCD Project"
# ════════════════════════════════════════════════════════════════

kubectl apply -f fluid-project.yaml
ok "ArgoCD project 'fluid-project' created"

# ════════════════════════════════════════════════════════════════
step "STEP 11 — Create ArgoCD Application"
# ════════════════════════════════════════════════════════════════

kubectl apply -f fluid-demo-app.yaml
ok "ArgoCD application 'fluid-demo' registered"

# Trigger first sync immediately
argocd app sync fluid-demo --insecure --grpc-web || \
  warn "Sync triggered — check UI for progress"

# ════════════════════════════════════════════════════════════════
step "STEP 12 — Final status"
# ════════════════════════════════════════════════════════════════

echo ""
argocd app list --insecure --grpc-web
echo ""
kubectl get pods -n fluid-demo 2>/dev/null || warn "fluid-demo namespace not ready yet — ArgoCD is syncing"

echo ""
echo -e "${GREEN}"
echo "╔══════════════════════════════════════════════════════════╗"
echo "║                 Setup Complete!                          ║"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║  ArgoCD UI  : $ARGOCD_URL"
echo "║  Username   : $NEW_USER"
echo "║  Password   : $NEW_PASSWORD"
echo "║                                                          ║"
echo "║  App        : fluid-demo                                 ║"
echo "║  Repo       : github.com/Sameerkatre/fluid-ai-devops     ║"
echo "║  Namespace  : fluid-demo                                 ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo -e "${YELLOW}⚠  Change your password after first login!${NC}"
echo "   argocd account update-password --account $NEW_USER"
echo ""
